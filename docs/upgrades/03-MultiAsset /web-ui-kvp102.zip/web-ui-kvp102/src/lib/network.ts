/**
 * Client-side network detection aligned with NETWORK.md domain map.
 *
 * Primary hosts:
 *   testnet.kovanica.online  → testnet
 *   mainnet.kovanica.online  → mainnet
 *   api.kovanica.online      → shared API (source still selected by UI)
 *   docs.kovanica.online     → docs (no live chain)
 *
 * Fallback: hostname containing "mainnet" → mainnet; otherwise testnet.
 */

export type NetworkId = "testnet" | "mainnet";

export function detectNetwork(): NetworkId {
  if (typeof window === "undefined") return "testnet";
  const host = window.location.hostname.toLowerCase();
  if (host === "mainnet.kovanica.online" || host.startsWith("mainnet.")) {
    return "mainnet";
  }
  // Explicit testnet host or any other (pre-mainnet default)
  return "testnet";
}

/** Hard redirect between network surfaces so storage/API clients stay isolated. */
export function switchNetworkHost(target: NetworkId): void {
  if (typeof window === "undefined") return;
  const { protocol, pathname, search, hash } = window.location;
  const host =
    target === "mainnet" ? "mainnet.kovanica.online" : "testnet.kovanica.online";
  window.location.href = `${protocol}//${host}${pathname}${search}${hash}`;
}

/** Public API base — shared entry until network-scoped API hosts exist. */
export const API_PUBLIC = "https://api.kovanica.online";

/** Docs host. */
export const DOCS_PUBLIC = "https://docs.kovanica.online";
