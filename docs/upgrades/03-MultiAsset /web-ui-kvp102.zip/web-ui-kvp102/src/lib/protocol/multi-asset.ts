import { api, apiPostJson } from "@/lib/api/client";

/** Native asset id — frozen string per KVP-102 / RFC-002. */
export const NATIVE_ASSET_ID = "KVNC" as const;

export type AssetId = string;

export type AssetBalance = {
  assetId: AssetId;
  /** Amount in atoms (smallest unit). */
  amountAtoms: number;
};

export type UtxoWithAsset = {
  tx: string;
  index: number;
  value: number;
  assetId: AssetId;
};

export type AddressBalances = {
  address: string;
  /** Deprecated scalar — always KVNC for backward compat. */
  balance: number;
  /** Per-asset map (preferred). Keys are asset_id strings. */
  balances: Record<AssetId, number>;
  utxos: UtxoWithAsset[];
};

export type HistoryEntry = {
  block?: string;
  tx: string;
  kind?: string;
  delta: number;
  assetId: AssetId;
};

export type AddressHistory = {
  address: string;
  balance: number;
  balances: Record<AssetId, number>;
  txs: HistoryEntry[];
};

export type PrepareRequest = {
  from: string;
  to: string;
  amount: number;
  /** Defaults to KVNC when omitted (API contract). */
  assetId?: AssetId;
};

export type PrepareResult = {
  sighash: string;
  fee: number;
  feeAssetId: AssetId;
  inputs: UtxoWithAsset[];
  outputs: Array<{ address: string; value: number; assetId: AssetId }>;
  change?: { value: number; assetId: AssetId };
};

/**
 * Normalise asset_id from API (snake_case or camelCase) → canonical string.
 * Native is always "KVNC".
 */
export function normalizeAssetId(raw: unknown): AssetId {
  if (typeof raw !== "string" || !raw.trim()) return NATIVE_ASSET_ID;
  const s = raw.trim();
  if (s.toUpperCase() === "KVNC") return NATIVE_ASSET_ID;
  return s.toLowerCase();
}

/** Short display label for badges (full id for native, truncated hex for others). */
export function shortAssetLabel(assetId: AssetId, maxHex = 8): string {
  if (assetId === NATIVE_ASSET_ID || assetId.toUpperCase() === "KVNC") {
    return "KVNC";
  }
  const id = assetId.toLowerCase();
  if (id.length <= maxHex + 2) return id;
  return `${id.slice(0, maxHex)}…`;
}

/**
 * Prefer balances map; fall back to scalar balance as KVNC only.
 * Matches the DoD in KVP-102-HTTP-asset_id-gap.md.
 */
export function balancesFromResponse(raw: {
  balance?: number;
  balances?: Record<string, number>;
}): Record<AssetId, number> {
  if (raw.balances && typeof raw.balances === "object") {
    const out: Record<AssetId, number> = {};
    for (const [k, v] of Object.entries(raw.balances)) {
      const id = normalizeAssetId(k);
      const n = typeof v === "number" ? v : Number(v);
      if (Number.isFinite(n)) out[id] = n;
    }
    if (Object.keys(out).length === 0 && typeof raw.balance === "number") {
      out[NATIVE_ASSET_ID] = raw.balance;
    }
    return out;
  }
  if (typeof raw.balance === "number") {
    return { [NATIVE_ASSET_ID]: raw.balance };
  }
  return {};
}

/**
 * GET /api/utxos?address=<addr>
 * Expects asset_id on each UTXO and balances map once node HTTP is live.
 */
export async function fetchAddressBalances(address: string): Promise<AddressBalances> {
  const addr = address.trim();
  if (!addr) throw new Error("Address required");

  const res = (await api(`/api/utxos?address=${encodeURIComponent(addr)}`)) as {
    address?: string;
    balance?: number;
    balances?: Record<string, number>;
    utxos?: Array<{
      tx?: string;
      index?: number;
      value?: number;
      asset_id?: string;
      assetId?: string;
    }>;
  };

  const balances = balancesFromResponse(res);
  const utxos: UtxoWithAsset[] = (res.utxos ?? []).map((u) => ({
    tx: String(u.tx ?? ""),
    index: Number(u.index ?? 0),
    value: Number(u.value ?? 0),
    assetId: normalizeAssetId(u.asset_id ?? u.assetId),
  }));

  return {
    address: res.address ?? addr,
    balance: typeof res.balance === "number" ? res.balance : balances[NATIVE_ASSET_ID] ?? 0,
    balances,
    utxos,
  };
}

/**
 * GET /api/history?address=<addr>
 */
export async function fetchAddressHistory(address: string): Promise<AddressHistory> {
  const addr = address.trim();
  if (!addr) throw new Error("Address required");

  const res = (await api(`/api/history?address=${encodeURIComponent(addr)}`)) as {
    address?: string;
    balance?: number;
    balances?: Record<string, number>;
    txs?: Array<{
      block?: string;
      tx?: string;
      kind?: string;
      delta?: number;
      asset_id?: string;
      assetId?: string;
    }>;
  };

  const balances = balancesFromResponse(res);
  const txs: HistoryEntry[] = (res.txs ?? []).map((t) => ({
    block: t.block,
    tx: String(t.tx ?? ""),
    kind: t.kind,
    delta: Number(t.delta ?? 0),
    assetId: normalizeAssetId(t.asset_id ?? t.assetId),
  }));

  return {
    address: res.address ?? addr,
    balance: typeof res.balance === "number" ? res.balance : balances[NATIVE_ASSET_ID] ?? 0,
    balances,
    txs,
  };
}

/**
 * POST /api/prepare — asset-scoped coin selection.
 * Fees always paid in KVNC. Omitted asset_id → KVNC (backward compatible).
 */
export async function prepareTransfer(params: PrepareRequest): Promise<PrepareResult> {
  const from = params.from.trim();
  const to = params.to.trim();
  if (!from || !to) throw new Error("from and to required");
  if (!Number.isFinite(params.amount) || params.amount <= 0) {
    throw new Error("amount must be a positive number of atoms");
  }

  const assetId = params.assetId ? normalizeAssetId(params.assetId) : NATIVE_ASSET_ID;

  const body: Record<string, unknown> = {
    from,
    to,
    amount: params.amount,
  };
  // Always send explicit asset_id so multi-asset path is exercised.
  body.asset_id = assetId;

  const res = (await apiPostJson("/api/prepare", body)) as {
    sighash?: string;
    fee?: number;
    fee_asset_id?: string;
    feeAssetId?: string;
    inputs?: Array<{
      tx?: string;
      index?: number;
      value?: number;
      asset_id?: string;
      assetId?: string;
    }>;
    outputs?: Array<{
      address?: string;
      value?: number;
      asset_id?: string;
      assetId?: string;
    }>;
    change?: { value?: number; asset_id?: string; assetId?: string };
  };

  return {
    sighash: String(res.sighash ?? ""),
    fee: Number(res.fee ?? 0),
    feeAssetId: normalizeAssetId(res.fee_asset_id ?? res.feeAssetId ?? NATIVE_ASSET_ID),
    inputs: (res.inputs ?? []).map((i) => ({
      tx: String(i.tx ?? ""),
      index: Number(i.index ?? 0),
      value: Number(i.value ?? 0),
      assetId: normalizeAssetId(i.asset_id ?? i.assetId),
    })),
    outputs: (res.outputs ?? []).map((o) => ({
      address: String(o.address ?? ""),
      value: Number(o.value ?? 0),
      assetId: normalizeAssetId(o.asset_id ?? o.assetId),
    })),
    change: res.change
      ? {
          value: Number(res.change.value ?? 0),
          assetId: normalizeAssetId(res.change.asset_id ?? res.change.assetId),
        }
      : undefined,
  };
}

/**
 * Build sorted list of assets for AssetPicker (native first, then others by id).
 */
export function assetPickerOptions(balances: Record<AssetId, number>): AssetBalance[] {
  const entries = Object.entries(balances).map(([assetId, amountAtoms]) => ({
    assetId: normalizeAssetId(assetId),
    amountAtoms,
  }));
  entries.sort((a, b) => {
    if (a.assetId === NATIVE_ASSET_ID) return -1;
    if (b.assetId === NATIVE_ASSET_ID) return 1;
    return a.assetId.localeCompare(b.assetId);
  });
  return entries;
}
